#include <iostream>
#include "starter.h"

using namespace std;

int main()
{
	int start_num1 = 20;
	int start_num2 = 15;			//create a few starter objects

    int final_num = start_num1 + start_num2;

    cout << start_num1 << " + " << start_num2 << " = " << final_num << endl; 
	//print out all the values for each object to validate your code
}
